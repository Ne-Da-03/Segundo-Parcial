using System;
using System.Windows.Forms; // Agregado para MessageBox
using Microsoft.Data.SqlClient;

namespace MinecraftManager.Utils
{
    public class DatabaseManager
    {
        private readonly string _connectionString;

        public DatabaseManager()
        {
            _connectionString = @"Data Source=DESKTOP-4RJHDDR\SQLEXPRESS;Initial Catalog=Mine;Integrated Security=True;TrustServerCertificate=True";
        }

        public SqlConnection GetConnection()
        {
            var connection = new SqlConnection(_connectionString);
            return connection;
        }

        public bool TestConnection()
        {
            try
            {
                using (var connection = GetConnection())
                {
                    connection.Open();
                    return true;
                }
            }
            catch (Exception)
            {
                return false;
            }
        }

        // Método separado para probar la conexión y mostrar mensajes
        public void ShowConnectionTest()
        {
            bool connectionResult = TestConnection();
            if (connectionResult)
            {
                MessageBox.Show("Conexión exitosa");
            }
            else
            {
                MessageBox.Show("Error de conexión");
            }
        }
    }
}