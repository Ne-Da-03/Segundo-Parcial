﻿using System;
using System;
using System.Windows.Forms;
using MinecraftManager.Services; // O usa  si ese es tu namespace real
using MinecraftManager.Models;   // O usa  si corresponde
using MinecraftManager.Utils;    // Para DatabaseManager
using Microsoft.VisualBasic; // Para usar InputBox

namespace Mine2._3
{
    public partial class Jugadores : Form
    {
        private readonly JugadorService _jugadorService;

        public Jugadores()
        {
            InitializeComponent();

            // Creamos el DatabaseManager y el servicio
            var dbManager = new DatabaseManager();
            _jugadorService = new JugadorService(dbManager);

            CargarJugadores(); // Cargar los datos al iniciar el formulario
        }

        private void CargarJugadores()
        {
            var jugadores = _jugadorService.ObtenerTodos();
            dataGridView1.DataSource = jugadores;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close(); // Botón de regresar
        }

        private void button2_Click(object sender, EventArgs e)
        {

            string nombre = Microsoft.VisualBasic.Interaction.InputBox("Nombre del jugador:", "Agregar jugador");
            string nivelStr = Microsoft.VisualBasic.Interaction.InputBox("Nivel del jugador:", "Agregar jugador");

            if (int.TryParse(nivelStr, out int nivel) && !string.IsNullOrWhiteSpace(nombre))
            {
                var nuevoJugador = new Jugador
                {
                    Nombre = nombre,
                    Nivel = nivel
                };

                _jugadorService.Crear(nuevoJugador);
                CargarJugadores(); // Refresca la tabla
            }
            else
            {
                MessageBox.Show("Datos inválidos. Intenta de nuevo.");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("Selecciona un jugador primero.");
                return;
            }

            var jugadorSeleccionado = (Jugador)dataGridView1.CurrentRow.DataBoundItem;

            string nuevoNombre = Interaction.InputBox("Nuevo nombre del jugador:", "Editar jugador", jugadorSeleccionado.Nombre);
            string nuevoNivelStr = Interaction.InputBox("Nuevo nivel del jugador:", "Editar jugador", jugadorSeleccionado.Nivel.ToString());

            if (int.TryParse(nuevoNivelStr, out int nuevoNivel) && !string.IsNullOrWhiteSpace(nuevoNombre))
            {
                jugadorSeleccionado.Nombre = nuevoNombre;
                jugadorSeleccionado.Nivel = nuevoNivel;

                _jugadorService.Actualizar(jugadorSeleccionado);
                CargarJugadores();
            }
            else
            {
                MessageBox.Show("Datos inválidos. Intenta de nuevo.");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
           
            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("Selecciona un jugador primero.");
                return;
            }

            var jugadorSeleccionado = (Jugador)dataGridView1.CurrentRow.DataBoundItem;

            var confirmacion = MessageBox.Show($"¿Estás seguro de eliminar a {jugadorSeleccionado.Nombre}?", "Confirmar eliminación", MessageBoxButtons.YesNo);

            if (confirmacion == DialogResult.Yes)
            {
                _jugadorService.Eliminar(jugadorSeleccionado.Id);
                CargarJugadores(); // Refresca la tabla
            }
        }

    }
}



