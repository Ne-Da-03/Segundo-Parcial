using System.Data;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using MinecraftManager.Utils;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Mine2._3
{
    public partial class Interfaz : Form
    {
        public Interfaz()
        {
            InitializeComponent();
            DatabaseManager dbManager = new DatabaseManager();
            bool connectionResult = dbManager.TestConnection();

            if (connectionResult)
            {
                MessageBox.Show("Conexi�n exitosa");
                MessageBox.Show("�Bienvenido!", "Mensaje de bienvenida", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
        }
       
        private void Form1_Load(object sender, EventArgs e)
        {
            
        }
       
        private void botonsalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Jugadores x = new Jugadores();
            x.ShowDialog();
        }
        private void Botoinventa_Click(object sender, EventArgs e)
        {
            inventario x = new inventario();
            x.ShowDialog();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }
    }
}
