﻿namespace Mine2._3
{
    partial class Interfaz
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Botoinventa = new Button();
            botonsalir = new Button();
            BotonJuga = new Button();
            errorProvider1 = new ErrorProvider(components);
            ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
            SuspendLayout();
            // 
            // Botoinventa
            // 
            Botoinventa.BackgroundImageLayout = ImageLayout.None;
            Botoinventa.Location = new Point(90, 201);
            Botoinventa.Name = "Botoinventa";
            Botoinventa.Size = new Size(259, 62);
            Botoinventa.TabIndex = 0;
            Botoinventa.Text = "Inventario";
            Botoinventa.UseVisualStyleBackColor = true;
            Botoinventa.Click += Botoinventa_Click;
            // 
            // botonsalir
            // 
            botonsalir.Location = new Point(370, 312);
            botonsalir.Name = "botonsalir";
            botonsalir.Size = new Size(70, 41);
            botonsalir.TabIndex = 1;
            botonsalir.Text = "Salir ";
            botonsalir.UseVisualStyleBackColor = true;
            botonsalir.Click += botonsalir_Click;
            // 
            // BotonJuga
            // 
            BotonJuga.Location = new Point(468, 201);
            BotonJuga.Name = "BotonJuga";
            BotonJuga.Size = new Size(240, 62);
            BotonJuga.TabIndex = 2;
            BotonJuga.Text = "Jugadores   ";
            BotonJuga.UseVisualStyleBackColor = true;
            BotonJuga.Click += button1_Click;
            // 
            // errorProvider1
            // 
            errorProvider1.ContainerControl = this;
            // 
            // Interfaz
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.fondomine;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(800, 450);
            Controls.Add(BotonJuga);
            Controls.Add(botonsalir);
            Controls.Add(Botoinventa);
            Name = "Interfaz";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Button Botoinventa;
        private Button botonsalir;
        private Button BotonJuga;
        private ErrorProvider errorProvider1;
    }
}
