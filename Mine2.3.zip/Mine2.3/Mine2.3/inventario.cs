﻿using System.Text;
using System.Windows.Forms;
using MinecraftManager.Models;
using MinecraftManager.Services;
using MinecraftManager.Utils;

namespace Mine2._3
{
    public partial class inventario : Form
    {
        private BloqueService _bloqueService; // ✅ Aquí está bien

        public inventario()
        {
            InitializeComponent();
            var dbManager = new DatabaseManager();
            _bloqueService = new BloqueService(dbManager); // ✅ Correcto

            comboBox1.Items.AddRange(new string[] { "Común", "Raro", "Épico", "Legendario" });
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string rarezaSeleccionada = comboBox1.SelectedItem.ToString();
            var bloquesFiltrados = _bloqueService.BuscarPorRareza(rarezaSeleccionada); // ✅ Correcto
            dataGridView1.DataSource = bloquesFiltrados;
        }

        private JugadorService _jugadorService;
        private InventarioService _inventarioService;

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void nombrejuga_Click(object sender, EventArgs e)
        {

        }
        private void inventario_Load(object sender, EventArgs e)
        {
            var dbManager = new DatabaseManager();
            var bloqueService = new BloqueService(dbManager);
            _jugadorService = new JugadorService(dbManager);
            _inventarioService = new InventarioService(dbManager, _jugadorService, bloqueService);

            // Cargar lista de jugadores en listBox
            comboBox2.DisplayMember = "Nombre"; // o el nombre que le hayas puesto a tu combo
            comboBox2.ValueMember = "Id";
            comboBox2.DataSource = _jugadorService.ObtenerTodos();

            // Asocia el evento si no lo hiciste por el diseñador
            comboBox2.SelectedIndexChanged += comboBox2_SelectedIndexChanged;

            numericUpDown1.Minimum = 1;
            numericUpDown1.Maximum = 999;
            numericUpDown1.Value = 1;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (comboBox2.SelectedItem is Jugador jugador)
            {
                var inventario = _inventarioService.ObtenerPorJugador(jugador.Id);
                dataGridView1.DataSource = inventario;
            }
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {

            if (comboBox2.SelectedItem is Jugador jugador && dataGridView1.CurrentRow?.DataBoundItem is Bloque bloque)
            {
                int cantidad = (int)numericUpDown1.Value;

                var inventario = new Inventario
                {
                    JugadorId = jugador.Id,
                    BloqueId = bloque.Id,
                    Cantidad = cantidad
                };

                _inventarioService.Agregar(inventario);
                MessageBox.Show("¡Bloque agregado al inventario!");

                // Actualizar vista
                dataGridView1.DataSource = _inventarioService.ObtenerPorJugador(jugador.Id);
            }
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow?.DataBoundItem is Inventario inventario)
            {
                int nuevaCantidad = (int)numericUpDown1.Value;

                inventario.Cantidad = nuevaCantidad;
                _inventarioService.Actualizar(inventario);

                MessageBox.Show("Cantidad actualizada.");
                dataGridView1.DataSource = _inventarioService.ObtenerPorJugador(inventario.JugadorId);
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow?.DataBoundItem is Inventario inventario)
            {
                var confirm = MessageBox.Show("¿Seguro que deseas eliminar este bloque del inventario?", "Confirmar", MessageBoxButtons.YesNo);
                if (confirm == DialogResult.Yes)
                {
                    _inventarioService.Eliminar(inventario.Id);
                    MessageBox.Show("Elemento eliminado.");

                    dataGridView1.DataSource = _inventarioService.ObtenerPorJugador(inventario.JugadorId);
                }
            }
        }

        private void btnExportarCSV_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count == 0)
            {
                MessageBox.Show("No hay datos para exportar.");
                return;
            }

            using (SaveFileDialog sfd = new SaveFileDialog() { Filter = "CSV (*.csv)|*.csv", FileName = "Inventario.csv" })
            {
                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        StringBuilder sb = new StringBuilder();

                        // Escribir cabecera
                        var headers = dataGridView1.Columns.Cast<DataGridViewColumn>();
                        sb.AppendLine(string.Join(",", headers.Select(c => c.HeaderText)));

                        // Escribir filas
                        foreach (DataGridViewRow row in dataGridView1.Rows)
                        {
                            var cells = row.Cells.Cast<DataGridViewCell>();
                            sb.AppendLine(string.Join(",", cells.Select(c => c.Value?.ToString())));
                        }

                        File.WriteAllText(sfd.FileName, sb.ToString(), Encoding.UTF8);
                        MessageBox.Show("Inventario exportado con éxito.");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error al exportar: " + ex.Message);
                    }
                }
            }
        }

    }
}



