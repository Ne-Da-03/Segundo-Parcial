﻿namespace Mine2._3
{
    partial class inventario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(inventario));
            nombrejuga = new Label();
            skin = new PictureBox();
            comboBox1 = new ComboBox();
            dataGridView1 = new DataGridView();
            regresar = new Button();
            comboBox2 = new ComboBox();
            btnAgregar = new Button();
            btnEditar = new Button();
            btnEliminar = new Button();
            numericUpDown1 = new NumericUpDown();
            btnExportarCSV = new Button();
            ((System.ComponentModel.ISupportInitialize)skin).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
            SuspendLayout();
            // 
            // nombrejuga
            // 
            nombrejuga.AutoSize = true;
            nombrejuga.Location = new Point(63, 73);
            nombrejuga.Name = "nombrejuga";
            nombrejuga.Size = new Size(94, 15);
            nombrejuga.TabIndex = 0;
            nombrejuga.Text = "Seleciona Rareza";
            nombrejuga.Click += nombrejuga_Click;
            // 
            // skin
            // 
            skin.BackColor = Color.Transparent;
            skin.BackgroundImage = (Image)resources.GetObject("skin.BackgroundImage");
            skin.BackgroundImageLayout = ImageLayout.Stretch;
            skin.InitialImage = null;
            skin.Location = new Point(163, 12);
            skin.Name = "skin";
            skin.Size = new Size(182, 199);
            skin.TabIndex = 2;
            skin.TabStop = false;
            skin.Click += pictureBox1_Click;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(49, 91);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(126, 23);
            comboBox1.TabIndex = 3;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(306, 105);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(360, 226);
            dataGridView1.TabIndex = 4;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // regresar
            // 
            regresar.Location = new Point(699, 389);
            regresar.Name = "regresar";
            regresar.Size = new Size(90, 46);
            regresar.TabIndex = 5;
            regresar.Text = "Regresar";
            regresar.UseVisualStyleBackColor = true;
            regresar.Click += button1_Click;
            // 
            // comboBox2
            // 
            comboBox2.FormattingEnabled = true;
            comboBox2.Location = new Point(149, 217);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(151, 23);
            comboBox2.TabIndex = 6;
            comboBox2.SelectedIndexChanged += comboBox2_SelectedIndexChanged;
            // 
            // btnAgregar
            // 
            btnAgregar.Location = new Point(22, 237);
            btnAgregar.Name = "btnAgregar";
            btnAgregar.Size = new Size(79, 36);
            btnAgregar.TabIndex = 7;
            btnAgregar.Text = "Agregar Bloques";
            btnAgregar.UseVisualStyleBackColor = true;
            btnAgregar.Click += btnAgregar_Click;
            // 
            // btnEditar
            // 
            btnEditar.Location = new Point(22, 279);
            btnEditar.Name = "btnEditar";
            btnEditar.Size = new Size(93, 28);
            btnEditar.TabIndex = 8;
            btnEditar.Text = "Editar o Eliminar";
            btnEditar.UseVisualStyleBackColor = true;
            btnEditar.Click += btnEditar_Click;
            // 
            // btnEliminar
            // 
            btnEliminar.Location = new Point(22, 313);
            btnEliminar.Name = "btnEliminar";
            btnEliminar.Size = new Size(71, 28);
            btnEliminar.TabIndex = 9;
            btnEliminar.Text = "Eliminar";
            btnEliminar.UseVisualStyleBackColor = true;
            btnEliminar.Click += btnEliminar_Click;
            // 
            // numericUpDown1
            // 
            numericUpDown1.Location = new Point(134, 284);
            numericUpDown1.Name = "numericUpDown1";
            numericUpDown1.Size = new Size(120, 23);
            numericUpDown1.TabIndex = 10;
            // 
            // btnExportarCSV
            // 
            btnExportarCSV.Location = new Point(712, 45);
            btnExportarCSV.Name = "btnExportarCSV";
            btnExportarCSV.Size = new Size(68, 70);
            btnExportarCSV.TabIndex = 11;
            btnExportarCSV.Text = "Exportar a CSV";
            btnExportarCSV.UseVisualStyleBackColor = true;
            btnExportarCSV.Click += btnExportarCSV_Click;
            // 
            // inventario
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.fondomine;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(800, 450);
            Controls.Add(btnExportarCSV);
            Controls.Add(numericUpDown1);
            Controls.Add(btnEliminar);
            Controls.Add(btnEditar);
            Controls.Add(btnAgregar);
            Controls.Add(comboBox2);
            Controls.Add(regresar);
            Controls.Add(dataGridView1);
            Controls.Add(comboBox1);
            Controls.Add(skin);
            Controls.Add(nombrejuga);
            Name = "inventario";
            Text = "inventario";
            Load += inventario_Load;
            ((System.ComponentModel.ISupportInitialize)skin).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label nombrejuga;
        private PictureBox skin;
        private ComboBox comboBox1;
        private DataGridView dataGridView1;
        private Button regresar;
        private ComboBox comboBox2;
        private Button btnAgregar;
        private Button btnEditar;
        private Button btnEliminar;
        private NumericUpDown numericUpDown1;
        private Button btnExportarCSV;
    }
}